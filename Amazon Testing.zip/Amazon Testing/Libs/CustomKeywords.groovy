
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "amazon.hello.printHello"(
    	String name	) {
    (new amazon.hello()).printHello(
        	name)
}


def static "amazon.hello.CheckDropdownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new amazon.hello()).CheckDropdownListElementExist(
        	object
         , 	option)
}
