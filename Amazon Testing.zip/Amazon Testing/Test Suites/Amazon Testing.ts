<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon Testing</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c8e9c823-b6d3-4bb2-9b55-4bca63f7ec5b</testSuiteGuid>
   <testCaseLink>
      <guid>507704ca-03c4-4296-bac8-e5800299ad38</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_001 Excel Data</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>e98a6641-fe96-496b-bd8a-d0b1baa2aa12</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/New Test Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>e98a6641-fe96-496b-bd8a-d0b1baa2aa12</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Items</value>
         <variableId>06788971-9e3b-4a06-a17e-b50f965243be</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>e98a6641-fe96-496b-bd8a-d0b1baa2aa12</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Category</value>
         <variableId>aa3e5903-1ff2-4732-843a-8dbf4b3353d1</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>f6026742-7e25-462a-8114-1a412f3a56fd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_001 Internal Data</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>7adcd2d8-1e95-4ead-b125-c65c1d467077</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_001 Global Variable</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>a78722d5-c888-40cb-92cb-75952a389d99</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>7347ca49-88cf-4036-b067-7ad5c0af4908</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_003</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>29ac0c24-81ba-4298-8e0c-daadf7b8cf89</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_004</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>912aed92-b15d-4ffa-984f-0f05f8773a66</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_005</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
