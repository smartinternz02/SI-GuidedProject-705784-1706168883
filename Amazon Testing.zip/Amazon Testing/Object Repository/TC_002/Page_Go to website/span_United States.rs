<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_United States</name>
   <tag></tag>
   <elementGuidId>8bd1498a-cccc-4795-8aaf-e961a3efe179</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='icp-dropdown']/span/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-dropdown-prompt</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fd242bbe-112b-41ab-a59c-e3d8efa17557</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-dropdown-prompt</value>
      <webElementGuid>03236b90-20a0-4810-a379-1710a50805a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    United States
                            </value>
      <webElementGuid>cb3b92fa-1d94-47db-88dd-c4648d23dfeb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-row a-spacing-extra-large a-spacing-top-base a-ws-row&quot;]/div[@class=&quot;a-column a-span12 a-ws-span10 a-ws-spacing-none&quot;]/div[@class=&quot;a-row a-ws-row&quot;]/div[@class=&quot;a-column a-span12 a-ws-span7&quot;]/span[@class=&quot;a-dropdown-container&quot;]/span[@id=&quot;icp-dropdown&quot;]/span[@class=&quot;a-button-inner&quot;]/span[@class=&quot;a-button-text a-declarative&quot;]/span[@class=&quot;a-dropdown-prompt&quot;]</value>
      <webElementGuid>8162d12f-cbbb-41f0-9d44-fce43ca69cd5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='icp-dropdown']/span/span/span</value>
      <webElementGuid>025c7275-19ba-42ce-9cae-b5fa6e0d16f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span/span/span/span</value>
      <webElementGuid>f3d0b744-306e-4ce0-8e3d-2db86577532d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                                    United States
                            ' or . = '
                                    United States
                            ')]</value>
      <webElementGuid>2b899f9e-2c1d-4814-8344-63b5815bf530</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
